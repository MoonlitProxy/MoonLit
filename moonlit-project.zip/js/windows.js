/* windows */
const IC={};
function focus(e){e.style.zIndex=++z;$("#app").textContent="\u2014 "+$("b",e).textContent}
function openWin(key,title,w,h,build,icon){
 if(wins[key]){const o=wins[key];o.style.display="";focus(o);return}
 w=Math.min(w,innerWidth-16);h=Math.min(h,innerHeight-110);
 const e=mk("div","win");e.style.cssText="width:"+w+"px;height:"+h+"px;left:"+Math.max(8,(innerWidth-w)/2+(cnt%5)*24)+"px;top:"+(40+(cnt++%5)*22)+"px";
 e.innerHTML='<div class="bar"><span class="wi"></span><b></b><span class="dots"><i class="fs">\u26F6</i><i class="y"></i><i class="g"></i><i class="r"></i></span></div><div class="wb"></div>';
 $("b",e).textContent=title;const wi=$(".wi",e);if(icon){wi.style.background=icon[1];glyph(wi,icon[0]);if(icon[2]){wi.textContent="";wi.style.background='url("'+icon[2]+'") center/cover'}}
 const bar=$(".bar",e);bar.onpointerdown=ev=>{focus(e);if(ev.target.closest(".dots")||e.classList.contains("max"))return;const sx=ev.clientX-e.offsetLeft,sy=ev.clientY-e.offsetTop;bar.setPointerCapture(ev.pointerId);bar.onpointermove=m=>{e.style.left=m.clientX-sx+"px";e.style.top=Math.max(26,m.clientY-sy)+"px"};bar.onpointerup=()=>{bar.onpointermove=null}};
 const dk=()=>document.querySelectorAll("#dock .ic").forEach(b=>b.classList.toggle("open",!!wins[b.dataset.k]));
 $(".r",e).onclick=()=>{e.remove();delete wins[key];$("#app").textContent="\u2014 Desktop";dk()};$(".y",e).onclick=()=>{e.style.display="none";$("#app").textContent="\u2014 Desktop"};
 $(".g",e).onclick=$(".fs",e).onclick=()=>e.classList.toggle("max");e.onpointerdown=()=>focus(e);
 $("#desk").appendChild(e);wins[key]=e;if(S.get("ml-mx",false))e.classList.add("max");build($(".wb",e));focus(e);dk()}
function toast(b,t,cb){const m=mk("div","mo",'<div><b>'+t+'</b><textarea class="in"></textarea><div style="display:flex;gap:8px"><button class="btn gh" style="flex:1">Cancel</button><button class="btn" style="flex:1">Save</button></div></div>');b.appendChild(m);const ta=$("textarea",m);ta.focus();return{ta,m,done:f=>{const bs=m.querySelectorAll("button");bs[0].onclick=()=>m.remove();bs[1].onclick=()=>{f(ta.value);m.remove()}}}}
function web(url){return b=>{b.innerHTML='<iframe sandbox="allow-scripts allow-same-origin allow-forms allow-popups"></iframe><div style="padding:6px 12px;font-size:12px;opacity:.7">If this stays blank, the site blocks being shown here. <a style="color:var(--acc)" target="_blank" rel="noopener" href="'+url+'">Open in a new tab</a></div>';const f=$("iframe",b);if(PX)f.setAttribute("sandbox","allow-scripts allow-forms allow-popups allow-modals");f.src=PX?viaPX(url):url}}
