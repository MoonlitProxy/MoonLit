# MoonLit

## Files
- `index.html` - the page (menu bar, desktop, lock screen)
- `styles.css` - all styling
- `js/` - the code, one file per part, loaded in this order:
  `util` `wallpapers` `wallpapers-extra` `system` `windows` `terminal` `settings` `apps-basic` `browser` `paint` `apps-misc` `rooms` `desktop` `extras`
- `_worker.js` - Cloudflare worker with the `/proxy` for the Browser app

Add a wallpaper: one line in `js/wallpapers-extra.js`. New Settings tabs and buttons live in `js/extras.js`.

## Settings
Appearance, Wallpaper (plus darken / blur / random at start), Apps (add website apps or paste-your-own code apps; open / close / hide / pin / edit / delete), Desktop & Dock, Customize (names, colors, corners, opacity, font, text size, custom CSS), Buttons (your own open / close / toggle / website / lock / wallpaper buttons in the menu bar or dock), Running (show, minimize, maximize, close open windows), Cloaking, About.

## Deploy
- Cloudflare Pages (easiest): upload the contents of `moonlit-cloudflare-upload.zip` (`index.html`, `styles.css`, `js/`, `_worker.js`) via Workers & Pages -> Create -> Pages -> Upload assets. Check `/proxy?ping=1` says `ok`.
- Cloudflare with Git/wrangler, Vercel, Node hosts: use this whole folder (`npm start` runs `server.js`).
