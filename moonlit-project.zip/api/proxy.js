// Vercel Edge Function (vercel.json rewrites /proxy -> /api/proxy)
import { handleProxy } from "../proxy-core.js";
export const config = { runtime: "edge" };
export default function handler(request) { return handleProxy(request); }
