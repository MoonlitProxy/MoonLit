// Cloudflare Pages Function -> served at /proxy
import { handleProxy } from "../proxy-core.js";
export const onRequest = ({ request }) => handleProxy(request);
