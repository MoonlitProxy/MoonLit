// Plain Node server (Node 18+, no dependencies): serves index.html and /proxy.
// Works on Render, Railway, Fly.io, Replit, a VPS, etc.  `npm start`
import http from "node:http";
import fs from "node:fs";
import dns from "node:dns/promises";
import path from "node:path";
import { Readable } from "node:stream";
import { fileURLToPath } from "node:url";
import { handleProxy, blockedHost } from "./proxy-core.js";

const dir = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;

// Resolve the hostname ourselves so a public name can't point at a private IP.
const check = async (host) => {
  try {
    const list = await dns.lookup(host, { all: true });
    return list.length > 0 && list.every((a) => !blockedHost(a.address));
  } catch { return false; }
};

http.createServer(async (req, res) => {
  const proto = (req.headers["x-forwarded-proto"] || "http").split(",")[0].trim();
  const url = new URL(req.url, `${proto}://${req.headers.host}`);

  if (url.pathname === "/proxy") {
    try {
      const init = { method: req.method, headers: req.headers };
      if (req.method !== "GET" && req.method !== "HEAD") { init.body = Readable.toWeb(req); init.duplex = "half"; }
      const out = await handleProxy(new Request(url, init), { check });
      res.writeHead(out.status, Object.fromEntries(out.headers));
      if (out.body) Readable.fromWeb(out.body).on("error", () => res.destroy()).pipe(res); else res.end();
    } catch (e) { if (!res.headersSent) res.writeHead(500); res.end("Proxy error"); }
    return;
  }
  if (url.pathname === "/" || url.pathname === "/index.html") {
    res.writeHead(200, { "content-type": "text/html; charset=utf-8", "cache-control": "no-cache" });
    return fs.createReadStream(path.join(dir, "index.html")).pipe(res);
  }
  res.writeHead(url.pathname === "/favicon.ico" ? 204 : 404); res.end();
}).listen(PORT, "0.0.0.0", () => console.log("MoonLit running on port " + PORT));
