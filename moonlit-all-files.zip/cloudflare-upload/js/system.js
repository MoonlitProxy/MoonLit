/* clock, battery, weather */
function tick(){const d=new Date();$("#lc").textContent=d.toLocaleTimeString([],{hour:"numeric",minute:"2-digit"}).replace(/ ?[AP]M/i,"");$("#ld").textContent=d.toLocaleDateString([],{weekday:"long",month:"long",day:"numeric"});$("#mc").textContent=d.toLocaleDateString([],{weekday:"short",month:"short",day:"numeric"})+"  "+d.toLocaleTimeString([],{hour:"numeric",minute:"2-digit",second:"2-digit"})}
setInterval(tick,1000);tick();
if(navigator.getBattery)navigator.getBattery().then(b=>{const u=()=>$("#bt").textContent=Math.round(b.level*100)+"%";u();b.onlevelchange=u}).catch(()=>{});
fetch("https://api.open-meteo.com/v1/forecast?latitude=40.71&longitude=-74.01&current=temperature_2m,weather_code&temperature_unit=fahrenheit").then(r=>r.json()).then(d=>{const c=d.current.weather_code,t=[[0,"\u2600\uFE0F","Clear"],[2,"\u26C5","Partly cloudy"],[3,"\u2601\uFE0F","Cloudy"],[48,"\uD83C\uDF2B\uFE0F","Foggy"],[67,"\uD83C\uDF27\uFE0F","Rain"],[77,"\u2744\uFE0F","Snow"],[82,"\uD83C\uDF27\uFE0F","Showers"],[99,"\u26C8\uFE0F","Thunderstorm"]].find(x=>c<=x[0]);$("#wt").textContent=Math.round(d.current.temperature_2m)+"\u00B0";$("#wd").textContent=t[2];$("#wx").style.display="block"}).catch(()=>{});
/* lock screen (accounts are saved only in this browser) */
let mode="in";const hs=p=>btoa(unescape(encodeURIComponent(p)));
document.querySelectorAll("#tabs button").forEach(b=>b.onclick=()=>{mode=b.dataset.m;document.querySelectorAll("#tabs button").forEach(x=>x.classList.toggle("on",x===b));$("#go").textContent=mode==="in"?"Log in":"Create account";$("#err").textContent=""});
function enter(u){user=u;$("#av").textContent=u[0].toUpperCase();$("#lock").classList.add("off");$("#lp").value=""}
$("#go").onclick=()=>{const u=$("#lu").value.trim(),p=$("#lp").value,e=$("#err");e.textContent="";if(!u||!p){e.textContent="Enter a username and password.";return}const us=S.get("ml-users",{});
 if(mode==="up"){if(us[u]){e.textContent="That username is taken.";return}us[u]=hs(p);S.set("ml-users",us);enter(u)}else if(us[u]!==hs(p)){e.textContent="Wrong username or password.";return}else enter(u)};
$("#lp").onkeydown=e=>{if(e.key==="Enter")$("#go").click()};$("#guest").onclick=()=>enter("Guest");$("#lk").onclick=()=>$("#lock").classList.remove("off");
