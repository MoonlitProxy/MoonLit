const $=(s,r=document)=>r.querySelector(s),mk=(t,c,h)=>{const e=document.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e};
const S={get(k,d){try{const v=localStorage.getItem(k);return v===null?d:JSON.parse(v)}catch(e){return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
S.list=(k,d=[])=>{const v=S.get(k,d);return Array.isArray(v)?v:d};S.dict=(k,d={})=>{const v=S.get(k,d);return v&&typeof v==="object"&&!Array.isArray(v)?v:d};
