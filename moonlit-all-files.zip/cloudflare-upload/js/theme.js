const ACC=["#2f7cf6","#8b5cf6","#ec4899","#f59e0b","#22c55e","#06b6d4","#ef4444","#14b8a6","#a3835b"];
function wall(k){S.set("ml-wp",k);$("#desk").style.background=WP[k][1]+" center/cover"}
function theme(k){S.set("ml-th",k);document.body.dataset.theme=k}
function accent(c){S.set("ml-ac",c);document.documentElement.style.setProperty("--acc",c)}
if(S.get("ml-cwp",null))WP.custom=["Custom",S.get("ml-cwp")];wall(WP[S.get("ml-wp","dusk")]?S.get("ml-wp","dusk"):"dusk");theme(S.get("ml-th","dark"));accent(S.get("ml-ac","#2f7cf6"));
function glyph(el,g){if(/^<svg/.test(g))el.innerHTML=g;else el.textContent=g}
let user="Guest",z=10,cnt=0;const wins={};
/* tab cloak */
const LOGO="data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%20100%20100%22%3E%3Crect%20width%3D%22100%22%20height%3D%22100%22%20rx%3D%2218%22%20fill%3D%22%232b3a4a%22/%3E%3Cpath%20d%3D%22M62%2022a30%2030%200%201%200%2016%2046A26%2026%200%200%201%2062%2022z%22%20fill%3D%22%23e9e5d6%22/%3E%3C/svg%3E";
function imgFrom(u){u=(u||"").trim();if(!u)return"";if(/^data:image\//i.test(u)||/\.(png|jpe?g|gif|svg|webp|ico|avif)(\?|#|$)/i.test(u))return u;try{const h=new URL(/^https?:\/\//i.test(u)?u:"https://"+u).hostname;return"https://www.google.com/s2/favicons?domain="+h+"&sz=128"}catch(e){return""}}
function iconHref(i){i=(i||"").trim();if(!i)return LOGO;if([...i].length<=4&&!/[.\/:]/.test(i))return"data:image/svg+xml,"+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text y=".9em" font-size="90">'+i.replace(/[<&]/g,"")+'</text></svg>');return imgFrom(i)||LOGO}
function cloak(t,i){S.set("ml-cl",[t,i]);document.title=t||"MoonLit";document.querySelectorAll("link[rel~=icon]").forEach(x=>x.remove());const l=document.createElement("link");l.rel="icon";l.href=iconHref(i);document.head.appendChild(l)}
{const c=S.get("ml-cl",null);if(Array.isArray(c))cloak(String(c[0]||""),String(c[1]||""))}
