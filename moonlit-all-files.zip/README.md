# MoonLit – deploy notes

The Browser app needs the `/proxy` endpoint. Pick ONE host:

| Host | What to do |
|---|---|
| Cloudflare Pages | Deploy this whole folder (Git, or `npx wrangler pages deploy .`). `functions/proxy.js` becomes `/proxy`. Dashboard drag-and-drop skips Functions, so use Git or wrangler. |
| Vercel | Import the folder / `vercel deploy`. `api/proxy.js` + `vercel.json` handle `/proxy`. |
| Render / Railway / Fly / Replit / VPS | Node 18+. Start command: `npm start` (runs `server.js`). |

Check it: open `https://YOUR-SITE/proxy?ping=1` - it should say `ok`.
If it does, the Browser app uses it automatically; if not, it falls back to free public relays.

Limits: the proxy is stateless (no cookies), so logins don't persist, and heavy
single-page apps (Google, Discord, etc.) may not render. Private/internal IPs are blocked.

## Easiest Cloudflare route (no CLI)
Upload the `cloudflare-upload` folder (just `index.html` + `_worker.js`) via
Workers & Pages -> Create -> Pages -> Upload assets. `_worker.js` contains the proxy,
so no `functions/` folder is needed. Then check `/proxy?ping=1` says `ok`.
