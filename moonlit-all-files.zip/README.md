# MoonLit

## Files
    index.html            page markup only
    css/base.css          desktop, top bar, icons, dock, windows
    css/browser.css       Browser app, Paint, YouTube, Rooms
    css/settings.css      Settings + app manager
    css/apps.css          Terminal, Calendar, Calculator, lock screen
    js/core.js            helpers + saved-data access
    js/wallpapers.js      all wallpapers (edit/add scenes here)
    js/theme.js           theme, accent, wallpaper, tab cloak
    js/system.js          clock, weather, lock screen
    js/windows.js         window manager
    js/settings.js        Settings (apps manager, cloaking, desktop options)
    js/apps.js            Calendar, Calculator, Clock, Notepad
    js/browser.js         Browser app
    js/tools.js           Paint, Camera, ID, Links, YouTube
    js/rooms.js           Rooms chat
    js/desktop.js         app list, desktop icons, dock, startup, shortcuts
    proxy-core.js         the /proxy backend (shared)
    _worker.js            Cloudflare: proxy + static files in one file
    functions/proxy.js    Cloudflare Pages Functions version (Git / wrangler)
    api/proxy.js, vercel.json   Vercel
    server.js, package.json     any Node host

## Cloudflare (easiest)
Upload the `cloudflare-upload` folder: Workers & Pages -> Create -> Pages -> Upload assets.
It must contain `index.html`, `_worker.js`, `css/` and `js/`.
Then open `/proxy?ping=1` on your site - it should say `ok`.

## Shortcuts
`\` puts the desktop icons back in place. The panic key (default `` ` ``) jumps to a page of your choice - both are editable in Settings.
